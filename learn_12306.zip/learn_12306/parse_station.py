import re
import requests

requests.packages.urllib3.disable_warnings()
url = 'https://kyfw.12306.cn/otn/resources/js/framework/station_name.js?station_version=1.8971'
response = requests.get(url, verify=False)
result = re.findall(u'([\u4e00-\u9fa5]+)\|([A-Z]+)', response.text)
stations= dict(result)
print(stations)


