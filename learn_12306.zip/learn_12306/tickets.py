# coding: utf-8

"""命令行火车票查看器

Usage:
    tickets [-gdtkz] <from> <to> <date>

Options:
    -h,--help   显示帮助菜单
    -g          高铁
    -d          动车
    -t          特快
    -k          快速
    -z          直达

Example:
    tickets 北京 上海 2016-10-10
    tickets -dg 成都 南京 2016-10-10
"""
from docopt import docopt
import re
import requests
import json
from prettytable import PrettyTable
requests.packages.urllib3.disable_warnings()
from stations import stations_dict
from colorama import init,Fore

init()

code_dict = {v: k for k, v in stations_dict.items()}

def cli():
    """command-line interface"""
    arguments = docopt(__doc__)
    from_station = stations_dict.get(arguments['<from>'])
    to_station = stations_dict.get(arguments['<to>'])
    date = arguments['<date>']
    # 构建URL
    url = 'https://kyfw.12306.cn/otn/leftTicket/query?leftTicketDTO.train_date={}&leftTicketDTO.from_station={}&leftTicketDTO.to_station={}&purpose_codes=ADULT'.format(date,from_station,to_station)
    header = '车次 始发站 到达站 出发时间 到达时间 历时 一等座 二等座 软卧 卧铺 硬座 无座'.split()
    r = requests.get(url, verify=False)
    raw_trains = r.json()['data']['result']
    pt = PrettyTable(header)
    trains = []
    for raw_train in raw_trains:
        #循环遍历每一辆车的信息
        date_list = raw_train.split('|')
        #获取车次号码
        train_number = date_list[3]
        #终点站
        to_station_code = date_list[7]
        to_station_name = code_dict[to_station_code]
        #始发站
        from_station_code = date_list[6]
        from_station_name = code_dict[from_station_code]
        #出发时间
        start_time = date_list[8]
        #到达时间
        arrive_time = date_list[9]
        # 总耗时
        time_fucked_up = date_list[10]
        # 一等座
        first_class_seat = date_list[31] or '--'
        # 二等座
        second_class_seat = date_list[30]or '--'
        # 软卧
        soft_sleep = date_list[23]or '--'
        # 硬卧
        hard_sleep = date_list[28]or '--'
        # 硬座
        hard_seat = date_list[29]or '--'
        # 无座
        no_seat = date_list[26]or '--'
        train = [train_number, Fore.GREEN+from_station_name+Fore.RESET, Fore.RED+to_station_name+Fore.RESET, Fore.GREEN+start_time+Fore.RESET, Fore.RED+arrive_time+Fore.RESET, time_fucked_up, first_class_seat,
                second_class_seat, soft_sleep, hard_sleep, hard_seat, no_seat]
        pt.add_row(train)
        trains.append(train)
    
    print(pt)  



if __name__ == '__main__':
    cli()

